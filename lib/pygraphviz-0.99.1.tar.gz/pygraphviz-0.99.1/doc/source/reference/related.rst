Related Pacakges
----------------

   - Python bindings distributed with Graphviz (graphviz-python):  http://www.graphviz.org/Download_linux.php

   - Pydot: http://dkbza.org/pydot.html

   - mfGraph: http://www.geocities.com/foetsch/mfgraph/index.htm

   - Yapgvb: http://yapgvb.sourceforge.net/
